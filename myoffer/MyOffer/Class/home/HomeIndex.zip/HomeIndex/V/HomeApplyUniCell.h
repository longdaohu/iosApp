//
//  HomeApplyUniCell.h
//  newOffer
//
//  Created by xuewuguojie on 2018/6/8.
//  Copyright © 2018年 徐金辉. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeApplyUniCell : UITableViewCell
@property(nonatomic,strong)NSArray *items;
@property(nonatomic,strong)NSDictionary *item;

@end
