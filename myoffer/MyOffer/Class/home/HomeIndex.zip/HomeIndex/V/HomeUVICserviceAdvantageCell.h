//
//  HomeUVICserviceAdvantageCell.h
//  MyOffer
//
//  Created by xuewuguojie on 2018/6/25.
//  Copyright © 2018年 UVIC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeUVICserviceAdvantageCell : UICollectionViewCell
@property(nonatomic,strong)NSDictionary *item;
@end
