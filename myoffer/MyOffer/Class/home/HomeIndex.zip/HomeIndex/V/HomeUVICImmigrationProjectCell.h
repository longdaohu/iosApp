//
//  HomeUVICImmigrationProjectCell.h
//  MyOffer
//
//  Created by xuewuguojie on 2018/6/25.
//  Copyright © 2018年 UVIC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeUVICImmigrationProjectCell : UICollectionViewCell
@property(nonatomic,strong)NSDictionary *item;
@end

@interface ItemCellView : UIView
@property(nonatomic,strong)NSDictionary *item;
@property(nonatomic,assign)CGFloat cell_height;

@end
