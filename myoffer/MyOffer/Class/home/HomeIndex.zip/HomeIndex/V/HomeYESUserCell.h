//
//  HomeYESUserCell.h
//  MyOffer
//
//  Created by xuewuguojie on 2018/6/26.
//  Copyright © 2018年 UVIC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeYESUserCell : UICollectionViewCell
@property(nonatomic,strong)NSDictionary *item;
@end
