//
//  MyofferFooterView.m
//  MyOffer
//
//  Created by xuewuguojie on 2018/6/15.
//  Copyright © 2018年 UVIC. All rights reserved.
//

#import "MyofferFooterView.h"
#import "AppButton.h"

@interface MyofferFooterView ()
@property(nonatomic,strong)UILabel *titleLab;
@property(nonatomic,strong)AppButton *emptyView;

@end

@implementation MyofferFooterView
+ (instancetype)footer{
    
    MyofferFooterView *footer = [[MyofferFooterView alloc] initWithFrame:CGRectMake(0, 0, XSCREEN_WIDTH, 30)];
    
    return footer;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        self.clipsToBounds = YES;
        
        UILabel *titleLab= [UILabel new];
        titleLab.text = @"我是有底线的";
        titleLab.textColor = XCOLOR_BLACK;
        self.titleLab = titleLab;
        titleLab.font = XFONT(14);
        [self addSubview:titleLab];
 
        AppButton *empty = [AppButton new];
        empty.titleLabel.font = XFONT(14);
        self.emptyView = empty;
        empty.type = MyofferButtonTypeImageTop;
        empty.margin = 20;
        [empty setImage: XImage(@"no_message") forState:UIControlStateNormal];
        [empty setTitle:@"没有数据！！！" forState:UIControlStateNormal];
        [self addSubview:empty];
        
    }
    return self;
}

- (void)layoutSubviews{
    
    [super layoutSubviews];
    
    CGSize content_size = self.bounds.size;
//    if (CGRectEqualToRect(self.titleLab.frame, CGRectZero)) {
//        if (self.titleLab.text.length > 0) {
            CGSize title_size =   [self.titleLab.text stringWithfontSize:14];
            CGFloat title_x = (content_size.width - title_size.width) * 0.5;
            CGFloat title_y = 0;
            self.titleLab.frame = CGRectMake(title_x, title_y, title_size.width, content_size.height);
//        }
//    }
 
    if (content_size.height > XSCREEN_WIDTH) {
        
        self.titleLab.alpha = 0;
        
        CGFloat empty_w =  content_size.width;
        CGFloat empty_h =  self.emptyView.currentImage.size.height * empty_w / self.emptyView.currentImage.size.width +  50;
        CGFloat empty_x =  0;
        CGFloat empty_y =  (content_size.height - empty_h) * 0.5;
        self.emptyView.frame = CGRectMake(empty_x, empty_y, empty_w, empty_h);
    }else{
        self.titleLab.alpha = 1;
    }
    
}

@end
